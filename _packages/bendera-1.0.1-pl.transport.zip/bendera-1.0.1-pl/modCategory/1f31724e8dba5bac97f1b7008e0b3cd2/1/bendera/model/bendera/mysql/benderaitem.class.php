<?php
require_once (dirname(dirname(__FILE__)) . '/benderaitem.class.php');
class BenderaItem_mysql extends BenderaItem {}