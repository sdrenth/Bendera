--------------------
Bendera
--------------------
Version: 1.0.0
Author: Sterc <modx@sterc.nl>
--------------------

A basic Extra for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/username/Bendera/issues