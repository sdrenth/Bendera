<?php
/**
 * @package bendera
 */
class BenderaItem extends xPDOSimpleObject {}
?>