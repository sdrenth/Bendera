<?php
class BenderaItems extends xPDOSimpleObject {}